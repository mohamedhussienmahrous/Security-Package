﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary.RSA
{
    public class RSA
    {
        public int Encrypt(int p, int q, int M, int e)
        {
            throw new NotImplementedException();
        }

        public int Decrypt(int p, int q, int C, int e)
        {
            throw new NotImplementedException();
        }
    }
}
